export function formScope(key: string): string {
  return `forms.${key}`;
}

export function messagesScope(key: string): string {
  return `messages.${key}`;
}
