import { Component } from '@angular/core';

@Component({
  selector: '[filter-select]',
  template: '<ng-content></ng-content>',
  styleUrls: ['./filter-select.component.scss']
})
export class FilterSelectComponent {}
